# Zepto Data & AI Platform

One repository containing data engineering, analytics/modeling, and an offline-first policy assistant.

## Setup
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
```

## Run
```bash
python data_pipeline/pipeline.py
python analytics/run_analytics.py
python -m support_assistant.ingest
uvicorn support_assistant.main:app --port 7860
```

## Design summary
The data module scrapes the first five catalogue pages and uses the fixed assignment rate **1 GBP = 105.50 INR**. It normalizes categories and books in SQLite and compares SQL JOIN output with `pd.merge`. The analytics module loads Titanic once, commits `titanic.csv`, generates EDA and metrics, uses train-only preprocessing, and saves a complete pipeline. The support module embeds eight policy documents locally, retrieves from ChromaDB, routes with LangGraph, and defaults to deterministic `MOCK_LLM=1` output.

## Required Git evidence
Run these commands yourself so your genuine history is visible:
```bash
git init
git branch -M main
git add . && git commit -m "Initialize capstone"
git checkout -b feature/data-pipeline
# Review/edit, then make two separate commits:
git add data_pipeline && git commit -m "Add scraper and cleaning"
# Make another meaningful edit
git add data_pipeline && git commit -m "Add SQL and pandas validation"
git checkout main
git merge --no-ff feature/data-pipeline -m "Merge data pipeline"
git log --graph --all --oneline
```

Review all generated outputs and write conclusions in your own words before submission.
