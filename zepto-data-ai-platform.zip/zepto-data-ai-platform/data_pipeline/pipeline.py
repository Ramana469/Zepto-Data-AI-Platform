from pathlib import Path
from urllib.parse import urljoin
import sqlite3, pandas as pd, requests
from bs4 import BeautifulSoup
BASE='https://books.toscrape.com/'; RATE=105.50
HERE=Path(__file__).parent; OUT=HERE/'outputs'; OUT.mkdir(exist_ok=True)
MAP={'One':1,'Two':2,'Three':3,'Four':4,'Five':5}
def get(url):
 r=requests.get(url,timeout=30,headers={'User-Agent':'EducationalCapstone/1.0'}); r.raise_for_status(); return BeautifulSoup(r.text,'html.parser')
def scrape():
 rows=[]
 for page in range(1,6):
  listing=urljoin(BASE,f'catalogue/page-{page}.html')
  for a in get(listing).select('article.product_pod h3 a'):
   s=get(urljoin(listing,a['href'])); cls=s.select_one('p.star-rating')['class']
   rows.append({'title':s.select_one('h1').get_text(strip=True),'price_raw':s.select_one('p.price_color').get_text(strip=True),'star_rating':next((x for x in cls if x in MAP),None),'availability':s.select_one('p.availability').get_text(' ',strip=True),'category':s.select('ul.breadcrumb li a')[-1].get_text(strip=True)})
 return pd.DataFrame(rows)
def clean(d):
 x=d.copy(); x['price_gbp']=pd.to_numeric(x.price_raw.str.replace(r'[^0-9.]','',regex=True),errors='coerce'); x['rating']=x.star_rating.map(MAP); x['in_stock']=x.availability.str.contains('In stock',case=False,na=False); x=x.dropna(subset=['title','category'])
 for c in ['price_gbp','rating']: x[c]=x[c].fillna(x[c].median())
 x['rating']=x.rating.round().clip(1,5).astype(int); x['price_inr']=(x.price_gbp*RATE).round(2)
 return x[['title','price_gbp','price_inr','rating','in_stock','category']].drop_duplicates()
Q={'where':'SELECT title,rating FROM books WHERE rating=5','order_limit':'SELECT title,price_gbp FROM books ORDER BY price_gbp DESC LIMIT 10','distinct':'SELECT DISTINCT category_name FROM categories','between':'SELECT title,price_gbp FROM books WHERE price_gbp BETWEEN 20 AND 40','in':'SELECT title,rating FROM books WHERE rating IN (4,5)','join':'SELECT b.title,b.price_gbp,b.price_inr,b.rating,b.in_stock,c.category_name FROM books b JOIN categories c ON b.category_id=c.category_id ORDER BY c.category_name,b.title'}
def main():
 d=clean(scrape()); assert len(d)>=60 and d.category.nunique()>=3; d.to_csv(OUT/'cleaned_books.csv',index=False)
 db=HERE/'zepto_books.db'; db.unlink(missing_ok=True); con=sqlite3.connect(db); con.execute('PRAGMA foreign_keys=ON'); con.executescript('CREATE TABLE categories(category_id INTEGER PRIMARY KEY,category_name TEXT UNIQUE NOT NULL); CREATE TABLE books(book_id INTEGER PRIMARY KEY,title TEXT NOT NULL,price_gbp REAL,price_inr REAL,rating INTEGER CHECK(rating BETWEEN 1 AND 5),in_stock INTEGER,category_id INTEGER REFERENCES categories(category_id));')
 for c in sorted(d.category.unique()): con.execute('INSERT INTO categories(category_name) VALUES(?)',(c,))
 ids=dict(con.execute('SELECT category_name,category_id FROM categories')); con.executemany('INSERT INTO books(title,price_gbp,price_inr,rating,in_stock,category_id) VALUES(?,?,?,?,?,?)',[(r.title,r.price_gbp,r.price_inr,int(r.rating),int(r.in_stock),ids[r.category]) for r in d.itertuples()]); con.commit()
 with open(OUT/'query_outputs.txt','w',encoding='utf-8') as f:
  for n,q in Q.items(): f.write(f'\n## {n}\n{q}\n{pd.read_sql(q,con).to_string(index=False)}\n')
 sql=pd.read_sql(Q['join'],con); books=pd.read_sql('SELECT * FROM books',con); cats=pd.read_sql('SELECT * FROM categories',con); merged=books.merge(cats,on='category_id')[['title','price_gbp','price_inr','rating','in_stock','category_name']].sort_values(['category_name','title']).reset_index(drop=True); pd.testing.assert_frame_equal(sql.reset_index(drop=True),merged,check_dtype=False); sql.to_csv(OUT/'sql_join.csv',index=False); merged.to_csv(OUT/'pandas_merge.csv',index=False); print(f'SUCCESS: {len(d)} books, {d.category.nunique()} categories')
if __name__=='__main__': main()
