# Data Pipeline
Run `python data_pipeline/pipeline.py`. Invalid numeric values are median-imputed; rows missing essential title/category identifiers are dropped. The fixed required rate is **1 GBP = 105.50 INR**. Six queries cover WHERE, ORDER BY, LIMIT, DISTINCT, BETWEEN, IN, and JOIN. SQL and pandas results are asserted equal.
