from pathlib import Path
import chromadb
from sentence_transformers import SentenceTransformer
try: from .config import COLLECTION
except ImportError: from config import COLLECTION
H=Path(__file__).parent
def build():
 files=sorted((H/'docs').glob('doc_*.txt')); docs=[p.read_text(encoding='utf-8') for p in files]; ids=[p.stem+'_chunk_0' for p in files]; model=SentenceTransformer('all-MiniLM-L6-v2'); client=chromadb.PersistentClient(path=str(H/'chroma_db'))
 try: client.delete_collection(COLLECTION)
 except Exception: pass
 c=client.create_collection(COLLECTION,metadata={'hnsw:space':'cosine'}); c.add(ids=ids,documents=docs,embeddings=model.encode(docs,normalize_embeddings=True).tolist()); print(f'Indexed {len(ids)} documents')
if __name__=='__main__': build()
