from typing import TypedDict,Literal
from langgraph.graph import StateGraph,START,END
from .config import MOCK_LLM
from .retrieval import retrieve
from .schemas import AskResponse
KEYS=('delivery','return','refund','membership','tracking','cancel','gift card','support hours')
class State(TypedDict,total=False): query:str; intent:Literal['policy_question','general_question']; answer:str; sources:list[str]; confidence:float
def classify_intent(s): return {'intent':'policy_question' if any(k in s['query'].lower() for k in KEYS) else 'general_question'} if MOCK_LLM else real_classify(s['query'])
def retrieve_and_answer(s):
 h=retrieve(s['query']); a=f"Based on the retrieved context: {h[0]['text'][:200]}" if MOCK_LLM else real_retry(s['query'],h); return AskResponse(answer=a,sources=[x['id'] for x in h],confidence=1).model_dump()
def direct_answer(s): return AskResponse(answer='I can only answer questions about Zepto policies right now.' if MOCK_LLM else real_retry(s['query'],[]),sources=[],confidence=1).model_dump()
def real_classify(q): raise RuntimeError('Optional real LLM backend not configured; use default MOCK_LLM=1')
def real_retry(q,h):
 # Three total attempts (initial + two retries); replace call below when implementing optional extension.
 for attempt in range(3):
  try: raise RuntimeError('Configure optional real LLM and validate AskResponse')
  except Exception as e: last=e
 return f'ERROR: {last}'
def route(s): return s['intent']
b=StateGraph(State); b.add_node('classify_intent',classify_intent); b.add_node('retrieve_and_answer',retrieve_and_answer); b.add_node('direct_answer',direct_answer); b.add_edge(START,'classify_intent'); b.add_conditional_edges('classify_intent',route,{'policy_question':'retrieve_and_answer','general_question':'direct_answer'}); b.add_edge('retrieve_and_answer',END); b.add_edge('direct_answer',END); graph=b.compile()
