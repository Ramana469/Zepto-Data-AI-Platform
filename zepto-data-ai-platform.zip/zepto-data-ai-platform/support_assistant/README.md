# Support Assistant
`ingest.py` loads the eight files, embeds them locally, and stores them in the `zepto_policies` ChromaDB collection. `retrieval.py` performs top-three cosine retrieval. `graph.py` runs `classify_intent`, then conditionally routes to `retrieve_and_answer` or `direct_answer`. Only generation/classification branches on `MOCK_LLM`; default mock mode makes no LLM call.

```text
Docs -> ingestion -> MiniLM embeddings -> ChromaDB
Query -> classification -> retrieval (policy) -> generation -> validated JSON
                        -> direct answer (general)
```

Run: `python -m support_assistant.ingest`, then `uvicorn support_assistant.main:app --port 7860`.

Test policy: `curl -X POST http://127.0.0.1:7860/ask -H "Content-Type: application/json" -d "{\"query\":\"What is the refund policy?\"}"`

Test general: `curl -X POST http://127.0.0.1:7860/ask -H "Content-Type: application/json" -d "{\"query\":\"Who discovered gravity?\"}"`

Record the two actual raw JSON responses here after running.

Docker from repository root: `docker build -f support_assistant/Dockerfile -t zepto-assistant .` then `docker run --rm -p 7860:7860 zepto-assistant`.
