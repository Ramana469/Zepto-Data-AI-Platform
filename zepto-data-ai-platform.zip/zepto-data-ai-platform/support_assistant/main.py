from fastapi import FastAPI
from .graph import graph
from .schemas import AskRequest,AskResponse
app=FastAPI(title='Zepto Policy Assistant')
@app.post('/ask',response_model=AskResponse)
def ask(r:AskRequest):
 x=graph.invoke({'query':r.query}); return AskResponse(answer=x['answer'],sources=x['sources'],confidence=x['confidence'])
