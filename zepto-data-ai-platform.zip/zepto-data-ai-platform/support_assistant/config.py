import os
MOCK_LLM=os.getenv('MOCK_LLM','1')!='0'; COLLECTION='zepto_policies'
