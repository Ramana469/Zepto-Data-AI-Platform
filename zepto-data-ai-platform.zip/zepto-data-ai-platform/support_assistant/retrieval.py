from pathlib import Path
import chromadb
from sentence_transformers import SentenceTransformer
from .config import COLLECTION
H=Path(__file__).parent; MODEL=None
def retrieve(q,k=3):
 global MODEL
 MODEL=MODEL or SentenceTransformer('all-MiniLM-L6-v2'); c=chromadb.PersistentClient(path=str(H/'chroma_db')).get_collection(COLLECTION); r=c.query(query_embeddings=MODEL.encode([q],normalize_embeddings=True).tolist(),n_results=k,include=['documents','distances']); return [{'id':i,'text':d} for i,d in zip(r['ids'][0],r['documents'][0])]
