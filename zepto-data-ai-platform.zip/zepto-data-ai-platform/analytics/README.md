# Analytics
Run `python analytics/run_analytics.py`. It loads Titanic once, saves `titanic.csv`, creates the exact six-column heatmap, four interpreted charts, three classifier metrics, imbalance variants, tuned RF OOB score, regression metrics, residual plot, and a reloadable complete pipeline. Review `outputs/executed_report.md` and expand conclusions in your own words.
