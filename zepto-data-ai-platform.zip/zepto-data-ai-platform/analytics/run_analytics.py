from pathlib import Path
import joblib,numpy as np,pandas as pd,seaborn as sns,matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split,GridSearchCV
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OneHotEncoder,StandardScaler
from sklearn.linear_model import LogisticRegression,LinearRegression
from sklearn.tree import DecisionTreeClassifier,plot_tree
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import *
from imblearn.pipeline import Pipeline as ImbPipeline
from imblearn.over_sampling import SMOTE
H=Path(__file__).parent; O=H/'outputs'; F=O/'figures'; M=H/'models'; [p.mkdir(parents=True,exist_ok=True) for p in [O,F,M]]; CSV=H/'titanic.csv'
def fig(n): plt.tight_layout(); plt.savefig(F/n,dpi=150,bbox_inches='tight'); plt.close()
def pre(num,cat): return ColumnTransformer([('num',Pipeline([('imp',SimpleImputer(strategy='median')),('scale',StandardScaler())]),num),('cat',Pipeline([('imp',SimpleImputer(strategy='most_frequent')),('onehot',OneHotEncoder(handle_unknown='ignore'))]),cat)])
def score(y,p,prob): return {'accuracy':accuracy_score(y,p),'precision':precision_score(y,p),'recall':recall_score(y,p),'f1':f1_score(y,p),'auc':roc_auc_score(y,prob),'confusion':confusion_matrix(y,p).tolist()}
def main():
 df=pd.read_csv(CSV) if CSV.exists() else sns.load_dataset('titanic'); df.to_csv(CSV,index=False); print(df.info()); print(df.describe(include='all')); print(df.shape)
 report=['# Executed Analytics Report',f'Shape: {df.shape}','## Missing percentages\n'+(df.isna().mean().mul(100).loc[lambda s:s>0].round(2).to_frame('percent').to_markdown())]; miss=df.isna().mean()*100; eda=df.copy(); decisions=[]
 for c,p in miss[miss>0].items():
  if p<5: eda=eda.dropna(subset=[c]); a='drop affected rows: under 5%'
  elif p<=30: eda[c]=eda[c].fillna(eda[c].median() if pd.api.types.is_numeric_dtype(eda[c]) else eda[c].mode()[0]); a='impute: 5%-30%'
  else: eda=eda.drop(columns=c); a='drop column: over 30%'
  decisions.append([c,round(p,2),a])
 report+=['## Cleaning decisions\n'+pd.DataFrame(decisions,columns=['column','missing_percent','decision']).to_markdown(index=False)]
 for c in ['age','fare']:
  _,ax=plt.subplots(1,2,figsize=(10,4)); sns.histplot(eda[c],kde=True,ax=ax[0]); sns.boxplot(x=eda[c],ax=ax[1]); fig(c+'_hist_box.png')
  q1,q3=eda[c].quantile([.25,.75]); i=q3-q1; report.append(f'{c} IQR outliers: {int(((eda[c]<q1-1.5*i)|(eda[c]>q3+1.5*i)).sum())}')
 mean,median,mode=eda.fare.mean(),eda.fare.median(),eda.fare.mode()[0]; report.append(f'Fare mean={mean:.2f}, median={median:.2f}, mode={mode:.2f}. Mean above median/mode indicates right skew.')
 rates=[]
 for s in eda.sex.unique(): rates.append([f'sex={s}',eda.loc[eda.sex==s,'survived'].mean()])
 for p in sorted(eda.pclass.unique()): rates.append([f'pclass={p}',eda.loc[eda.pclass==p,'survived'].mean()])
 for s in eda.sex.unique():
  for p in sorted(eda.pclass.unique()): rates.append([f'{s}, class {p}',eda.loc[(eda.sex==s)&(eda.pclass==p),'survived'].mean()])
 report.append('## Survival rates\n'+pd.DataFrame(rates,columns=['group','rate']).to_markdown(index=False)); cols=['survived','pclass','age','sibsp','parch','fare']; corr=eda[cols].corr(); sns.heatmap(corr,annot=True,cmap='coolwarm',center=0); fig('correlation.png'); pairs=corr.where(np.triu(np.ones(corr.shape),1).astype(bool)).stack().rename('r').reset_index(); pairs['abs']=pairs.r.abs(); report.append('## Top correlations\n'+pairs.nlargest(2,'abs').to_markdown(index=False))
 charts=[('sex_survival.png',lambda:sns.barplot(data=eda,x='sex',y='survived'),'Sex groups show different observed survival rates.'),('class_survival.png',lambda:sns.barplot(data=eda,x='pclass',y='survived'),'Class groups show different observed survival rates.'),('fare_survival.png',lambda:sns.boxplot(data=eda,x='survived',y='fare'),'Fare distribution differs by outcome.'),('age_sex.png',lambda:sns.boxplot(data=eda,x='sex',y='age',hue='survived'),'Age and sex jointly provide a more nuanced view.')]
 for n,draw,text in charts: plt.figure(figsize=(7,4)); draw(); fig(n); report.append(f'### {n}\n{text} Review the executed chart and expand this interpretation in your own words.')
 z=pd.DataFrame(StandardScaler().fit_transform(eda[['age','fare']]),columns=['age_z','fare_z']); report.append('## EDA standardization\n'+z.agg(['mean','std']).to_markdown())
 feats=['pclass','age','sibsp','parch','fare','sex','embarked']; num=feats[:5]; cat=feats[5:]; X=df[feats]; y=df.survived; Xtr,Xte,ytr,yte=train_test_split(X,y,test_size=.2,stratify=y,random_state=42); models={'Logistic Regression':LogisticRegression(max_iter=1000),'Decision Tree':DecisionTreeClassifier(max_depth=5,random_state=42),'Random Forest':RandomForestClassifier(n_estimators=200,random_state=42)}; rows=[]; fitted={}
 plt.figure(figsize=(7,5))
 for name,est in models.items():
  p=Pipeline([('preprocessor',pre(num,cat)),('classifier',est)]).fit(Xtr,ytr); fitted[name]=p; pred=p.predict(Xte); prob=p.predict_proba(Xte)[:,1]; m=score(yte,pred,prob); rows.append({'model':name,**m}); fpr,tpr,_=roc_curve(yte,prob); plt.plot(fpr,tpr,label=name)
  plt.figure(); sns.heatmap(confusion_matrix(yte,pred),annot=True,fmt='d'); fig(name.replace(' ','_')+'_cm.png')
 plt.figure();
 for name,p in fitted.items(): fpr,tpr,_=roc_curve(yte,p.predict_proba(Xte)[:,1]); plt.plot(fpr,tpr,label=name)
 plt.legend(); fig('roc.png'); comp=pd.DataFrame(rows); comp.to_csv(O/'classification_metrics.csv',index=False); t=fitted['Decision Tree']; plt.figure(figsize=(20,10)); plot_tree(t['classifier'],feature_names=t['preprocessor'].get_feature_names_out(),class_names=['Not survived','Survived'],filled=True,max_depth=3); fig('decision_tree.png')
 imb=[]
 for n,e in [('baseline',LogisticRegression(max_iter=1000)),('balanced',LogisticRegression(max_iter=1000,class_weight='balanced'))]:
  p=Pipeline([('preprocessor',pre(num,cat)),('classifier',e)]).fit(Xtr,ytr); q=p.predict(Xte); imb.append([n,precision_score(yte,q),recall_score(yte,q),f1_score(yte,q)])
 sm=ImbPipeline([('preprocessor',pre(num,cat)),('smote',SMOTE(random_state=42)),('classifier',LogisticRegression(max_iter=1000))]).fit(Xtr,ytr); q=sm.predict(Xte); imb.append(['SMOTE train only',precision_score(yte,q),recall_score(yte,q),f1_score(yte,q)]); imb=pd.DataFrame(imb,columns=['variant','precision','recall','f1']); imb.to_csv(O/'imbalance.csv',index=False)
 rf=Pipeline([('preprocessor',pre(num,cat)),('classifier',RandomForestClassifier(oob_score=True,bootstrap=True,random_state=42))]); grid=GridSearchCV(rf,{'classifier__n_estimators':[100,200],'classifier__max_depth':[None,5,10],'classifier__max_features':['sqrt','log2']},cv=5,scoring='f1').fit(Xtr,ytr); joblib.dump(grid.best_estimator_,M/'best_titanic_pipeline.joblib'); loaded=joblib.load(M/'best_titanic_pipeline.joblib'); assert len(loaded.predict(Xte.head()))==5
 rx=df[['pclass','age','sibsp','parch','survived','sex','embarked']]; ry=df.fare; a,b,c,d=train_test_split(rx,ry,test_size=.2,random_state=42); reg=Pipeline([('preprocessor',pre(['pclass','age','sibsp','parch','survived'],['sex','embarked'])),('regressor',LinearRegression())]).fit(a,c); pred=reg.predict(b); mae=mean_absolute_error(d,pred); rmse=mean_squared_error(d,pred)**.5; r2=r2_score(d,pred); pn=len(reg['preprocessor'].get_feature_names_out()); adj=1-(1-r2)*(len(d)-1)/(len(d)-pn-1); plt.scatter(pred,d-pred); plt.axhline(0,color='black'); fig('residuals.png'); regm=pd.DataFrame([['Linear Regression',mae,rmse,r2,adj]],columns=['model','MAE','RMSE','R2','Adjusted R2']); regm.to_csv(O/'regression_metrics.csv',index=False)
 report += ['## Class balance\n'+y.value_counts().to_frame('count').to_markdown(),'## Classifiers\n'+comp.to_markdown(index=False),'## Imbalance handling\n'+imb.to_markdown(index=False),f'## Grid search\nBest: `{grid.best_params_}`; OOB={grid.best_estimator_["classifier"].oob_score_:.4f}','## Regression\n'+regm.to_markdown(index=False)+'\nReview residuals.png and state whether the spread is random or funnel-shaped.','## Recommendation\nUse the classifier with the best held-out balance of F1 and AUC, while checking precision/recall for the business cost of errors. Cite the exact executed values above in your final wording. The saved complete tuned pipeline reload test passed.']; (O/'executed_report.md').write_text('\n\n'.join(report),encoding='utf-8'); print('SUCCESS')
if __name__=='__main__': main()
